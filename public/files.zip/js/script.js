$(document).ready(function(){
	
	var q = $('.query')
	
	$('.field .phone, .register-form #email').mask('00000000000')
	
	$('.add-fb').click(function(){
		
		$('.popup-container.reviewp').fadeIn(100)
		return false
	})
	
	$('.r-form a.button').click(function(){
		
		var f = $('.r-form form')
		
		if ($('.hrating', f).val() == 0){
			alert('Поставьте оценку');
			return false
		}
		
		if ($('textarea', f).val().trim() == ''){
			alert('Заполните текст отзыва');
			return false
		}
		
		var data = $('.r-form form').serialize();
		
		$.post('/content/addreview?'+data, 
		
			function(data){
				$('.popup-content .review').html(data).height(378);
			}
		
		)
		
	})
	
	$('.close').click(function(){
		$(this).parent().parent().fadeOut(100)
	})
	
	$('.query .tab').click(function(){
				
		$('.query .tab').removeClass('active-tab')
		$(this).addClass('active-tab')
		
		$('.in_clinic, .in_home', q).hide()
		$('.'+$(this).data('ds'), q).show()
		
		$('.where').val($(this).data('ds'))
		
	})
	
	$('.save, .unsave').click(function(){
		el = $(this)
		$.post('/content/addfavorite'+$(this).data('params'), 
		
			function(data){
				if (data == 'accept'){
					if (el.hasClass('save')){
						el.removeClass('save').addClass('unsave').attr('title', 'Удалить из избранных');
					}else{
						el.removeClass('unsave').addClass('save').attr('title', 'Добавить в избранное');
					}
				}else{
					alert(data);
				}
			}
		
		)
		
		return false
	})
	
	$('.addquery').click(function(){
		
		var f = $('.query form')
		
		if ($('.where').val() == 'in_home'){
			
			if ($('.qcity', f).val() == ''){
				alert('Введите название населенного пункта');
				return false
			}
			
		}
		
		var data = $('.query form').serialize();
		
		$.post('/content/addquery?'+data, 
		
			function(data){
				$('.query').before($(data));
				$('.query').hide();
			}
		
		)
		
		return false
		
	})
	
	$('.subs .button').click(function(){
		window.location.href = '/search?q='+$(this).prev().val();
	})
	
	$('.subs input[type=text]').keydown(function(e){
		if(e.keyCode === 13) {
			window.location.href = '/search?q='+$(this).val();
			return false
		}
	})
	
	$('.open-query').click(function(){
		
		$('.popup-content').find('.ms').remove()
		$('.query').show();
		$('.in_home').hide()
		$('.tabs', q).show();
		
		var id = $(this).data('id')
		var el = $(this)
		
		$.post('/content/getdoctor?id='+id, 
		
			function(data){
				doctor = JSON.parse(data)
				
				$('form', q)[0].reset()
				
				$('input[name=doctor]', q).val(doctor.doctor.id)
				$('input[name=doctor-name]', q).val(doctor.doctor.title)
				
				$('select[name=clinic]', q).html('')
				
				for (key in doctor.clinics){
					$('select[name=clinic]', q).append($('<option value="'+doctor.clinics[key].id+'">'+doctor.clinics[key].title+' '+doctor.clinics[key].adress+'</option>'))
				}
				
				$('select[name=spec]', q).html('')
				
				for (key in doctor.specs){
					$('select[name=spec]', q).append($('<option value="'+doctor.specs[key].id+'">'+doctor.specs[key].title+'</option>'))
				}
				
				if (doctor.doctor.home == 1){
					$('.tabs', q).show();
				}else{
					$('.tabs', q).hide();
				}
				$('.query_id').val('')
				
				if (doctor.user){
						$('input[name=fio]', q).val(doctor.user.fio)
						var phone = parseInt(doctor.user.phone)
						if (isNaN(phone)){
							phone = ''
						}
						$('input[name=phone]', q).val(phone)
					}
				
				if (el.hasClass('add-here-query')){
			
					dt = el.data('dt')
					
					dts = dt.split('|')
					$('#datepicker_value').val(dts[0])
					$( "#datepicker" ).datepicker( "setDate", new Date(dts[0]));
					$('.time select').val(dts[1])
					
					
					
				}
				
				$('.popup-container.queryp').fadeIn(100)
			}
		
		)
		
		return false
		
	})
	
})